package bernal.martin.mydigimind_bernalmartin

import java.util.ArrayList

class Carrito{
    var recordatorios= ArrayList<Recordatorio>()
    fun agregar(p: Recordatorio) : Boolean{
        return recordatorios.add(p)
    }
}